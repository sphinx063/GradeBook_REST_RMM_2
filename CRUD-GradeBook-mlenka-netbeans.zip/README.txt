Name: Mrutyunjaya Lenka
ID : 1209243486
------------------------------------------------------------------------------------------------------------------
1. Run the server (CRUD-GradeBook-mlenka-netbeans)
2. Run the client (CRUD-GradeBook-mlenka-netbeans-cl)
3. Please give INTEGER input for id fields, score, max score and weight fields.
4. Please give input for all required fields.
5. A student can appeal once for each gradeitem.
6. The gradeitem id's are integers starting from 1 and are icremented by 1. When deleted an id is not used again. The next created gradeitem use the next number in sequence. (Please refer the location field while creating gradeitems.)
7. The students are hardcoded with id values(380,381,382,383). Please use these ids whenever asked for student Id.